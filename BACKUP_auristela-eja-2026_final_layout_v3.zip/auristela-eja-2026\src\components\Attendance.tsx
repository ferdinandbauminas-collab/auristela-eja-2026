import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Teacher, Student, Discipline, AttendanceRecord } from '../lib/supabase';
import { Check, X, Send, LogOut, Users, BookOpen, Calendar as CalendarIcon, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import CustomSelect from './CustomSelect';

interface Props {
    teacher: Teacher;
    onLogout: () => void;
}

const DUMMY_DISCIPLINES: Discipline[] = [
    { discipline_id: 'disc1', discipline_name: 'LÍNGUA PORTUGUESA', teacher_id: '', classes: ['MÓDULO II A', 'MÓDULO II B', 'MÓDULO IV C'] },
    { discipline_id: 'disc2', discipline_name: 'PROJETO DE VIDA', teacher_id: '', classes: ['VII ETAPA A', 'VII ETAPA B'] }
];

const Attendance = ({ teacher, onLogout }: Props) => {
    const [disciplines, setDisciplines] = useState<Discipline[]>(DUMMY_DISCIPLINES);
    const [selectedDiscipline, setSelectedDiscipline] = useState<Discipline | null>(null);
    const [selectedClass, setSelectedClass] = useState<string>('');
    const [students, setStudents] = useState<Student[]>([]);
    const [attendance, setAttendance] = useState<Record<string, 'present' | 'absent'>>({});
    const [saving, setSaving] = useState(false);
    const [today] = useState(new Date().toLocaleDateString('pt-BR'));

    // Modais state
    const [isDisciplineModalOpen, setIsDisciplineModalOpen] = useState(false);
    const [isClassModalOpen, setIsClassModalOpen] = useState(false);

    useEffect(() => {
        async function loadData() {
            try {
                const { data } = await supabase.from('disciplines').select('*').eq('teacher_id', teacher.id);
                if (data && data.length > 0) {
                    setDisciplines(data as Discipline[]);
                }
            } catch (err) {
                console.error('Erro ao buscar disciplinas:', err);
            }
        }
        loadData();
    }, [teacher]);

    useEffect(() => {
        if (selectedClass) {
            async function loadStudents() {
                const { data } = await supabase.from('students').select('*').eq('class', selectedClass).order('name');
                if (data) {
                    setStudents(data);
                    const initial: Record<string, 'present' | 'absent'> = {};
                    data.forEach(s => initial[s.id] = 'present');
                    setAttendance(initial);
                }
            }
            loadStudents();
        }
    }, [selectedClass]);

    const handleSave = async () => {
        if (!selectedDiscipline || !selectedClass) return;
        setSaving(true);

        const records: AttendanceRecord[] = students.map(s => ({
            teacher_name: teacher.name,
            discipline: selectedDiscipline.discipline_name,
            class_name: selectedClass,
            student_name: s.name,
            status: attendance[s.id],
            date: new Date().toISOString().split('T')[0]
        }));

        const { error } = await supabase.from('attendance').insert(records);
        setSaving(false);

        if (!error) {
            alert('Frequência registrada com sucesso!');
            setSelectedClass('');
        } else {
            alert('Falha ao salvar: ' + error.message);
        }
    };

    const disciplineOptions = disciplines.map((d, idx) => ({
        value: d.discipline_id,
        label: d.discipline_name,
        color: ['#10b981', '#3b82f6', '#6366f1', '#14b8a6', '#f43f5e'][idx % 5]
    }));

    const classOptions = (selectedDiscipline?.classes || []).map((c, idx) => ({
        value: c,
        label: c,
        color: ['#059669', '#0d9488', '#0891b2', '#0284c7', '#2563eb'][idx % 5]
    }));

    const handleDisciplineChange = (id: string) => {
        const disc = disciplines.find(d => d.discipline_id === id);
        setSelectedDiscipline(disc || null);
        setSelectedClass('');
        setIsDisciplineModalOpen(false);
    };

    const handleClassChange = (className: string) => {
        setSelectedClass(className);
        setIsClassModalOpen(false);
    };

    return (
        <div style={{ paddingTop: '10px', height: '100%', display: 'flex', flexDirection: 'column' }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#94a3b8', marginBottom: '4px' }}>
                        <CalendarIcon size={14} />
                        <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>{today}</span>
                    </div>
                    <h1 style={{ fontSize: '1.2rem', color: '#064e3b', fontWeight: 800 }}>{teacher.name}</h1>
                </div>
                <button onClick={onLogout} style={{ border: 'none', background: 'rgba(239, 68, 68, 0.05)', color: '#ef4444', padding: '10px', borderRadius: '14px', cursor: 'pointer' }}>
                    <LogOut size={20} />
                </button>
            </header>

            {/* SELECTION CARDS */}
            <div style={{ display: 'grid', gap: '8px', marginBottom: '16px' }}>
                {/* Discipline Card */}
                <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setIsDisciplineModalOpen(true)}
                    style={{
                        width: '100%', padding: '16px 20px', borderRadius: '24px', border: 'none',
                        background: 'white', cursor: 'pointer', textAlign: 'left',
                        boxShadow: '0 4px 12px -2px rgba(0,0,0,0.05)',
                        display: 'flex', alignItems: 'center', gap: '16px'
                    }}
                >
                    <div style={{
                        width: '44px', height: '44px', background: 'rgba(16, 185, 129, 0.05)',
                        borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}>
                        <BookOpen size={22} color="#10b981" />
                    </div>
                    <div style={{ flex: 1 }}>
                        <p style={{ color: '#94a3b8', fontSize: '0.65rem', fontWeight: 800, textTransform: 'uppercase', marginBottom: '2px' }}>Disciplina</p>
                        <h2 style={{ fontSize: '0.95rem', color: '#064e3b', fontWeight: 800, lineHeight: 1.2 }}>
                            {selectedDiscipline ? selectedDiscipline.discipline_name : 'QUAL A DISCIPLINA?'}
                        </h2>
                    </div>
                    <ChevronRight size={18} color="#cbd5e1" />
                </motion.button>

                {/* Class Card */}
                <motion.button
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => selectedDiscipline && setIsClassModalOpen(true)}
                    style={{
                        width: '100%', padding: '16px 20px', borderRadius: '24px', border: 'none',
                        background: selectedDiscipline ? 'white' : 'rgba(0,0,0,0.02)',
                        cursor: selectedDiscipline ? 'pointer' : 'not-allowed',
                        textAlign: 'left',
                        boxShadow: selectedDiscipline ? '0 4px 12px -2px rgba(0,0,0,0.05)' : 'none',
                        display: 'flex', alignItems: 'center', gap: '16px',
                        opacity: selectedDiscipline ? 1 : 0.5
                    }}
                >
                    <div style={{
                        width: '44px', height: '44px', background: 'rgba(59, 130, 246, 0.05)',
                        borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}>
                        <Users size={22} color="#3b82f6" />
                    </div>
                    <div style={{ flex: 1 }}>
                        <p style={{ color: '#94a3b8', fontSize: '0.65rem', fontWeight: 800, textTransform: 'uppercase', marginBottom: '2px' }}>Turma (Módulo)</p>
                        <h2 style={{ fontSize: '0.95rem', color: '#064e3b', fontWeight: 800, lineHeight: 1.2 }}>
                            {selectedClass ? selectedClass : 'PARA QUAL TURMA?'}
                        </h2>
                    </div>
                    <ChevronRight size={18} color="#cbd5e1" />
                </motion.button>
            </div>

            {/* Modais */}
            <CustomSelect
                options={disciplineOptions}
                value={selectedDiscipline?.discipline_id || ''}
                onChange={handleDisciplineChange}
                externalOpen={isDisciplineModalOpen}
                onClose={() => setIsDisciplineModalOpen(false)}
                hideTrigger={true}
                showSearch={false}
            />

            <CustomSelect
                options={classOptions}
                value={selectedClass}
                onChange={handleClassChange}
                externalOpen={isClassModalOpen}
                onClose={() => setIsClassModalOpen(false)}
                hideTrigger={true}
                showSearch={false}
            />

            <AnimatePresence>
                {selectedClass && (
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.4 }}
                        style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}
                    >
                        <div className="glass-card" style={{ padding: '0', overflow: 'hidden', flex: 1, display: 'flex', flexDirection: 'column' }}>
                            <div style={{ padding: '20px 24px', borderBottom: '1px solid rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                    <div style={{ width: '36px', height: '36px', background: 'rgba(5, 150, 105, 0.05)', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                        <Users size={18} color="#059669" />
                                    </div>
                                    <h3 style={{ fontSize: '1rem', fontWeight: 800, color: '#064e3b' }}>Lista de Alunos</h3>
                                </div>
                                <div style={{ padding: '4px 12px', background: '#059669', borderRadius: '10px', color: 'white', fontSize: '0.8rem', fontWeight: 800 }}>
                                    {students.length}
                                </div>
                            </div>

                            <div style={{ flex: 1, overflowY: 'auto' }}>
                                {students.map((s, idx) => (
                                    <motion.div
                                        initial={{ opacity: 0, x: -10 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: idx * 0.02 }}
                                        key={s.id}
                                        style={{
                                            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                            padding: '16px 24px',
                                            borderBottom: '1px solid rgba(0,0,0,0.03)'
                                        }}
                                    >
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
                                            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: attendance[s.id] === 'present' ? '#10b981' : '#ef4444' }} />
                                            <span style={{ fontWeight: 700, fontSize: '0.95rem', color: '#1e293b' }}>{s.name}</span>
                                        </div>
                                        <div style={{ display: 'flex', background: '#f1f5f9', borderRadius: '12px', padding: '3px' }}>
                                            <button
                                                onClick={() => setAttendance({ ...attendance, [s.id]: 'present' })}
                                                style={{
                                                    padding: '6px 16px', borderRadius: '10px', border: 'none', cursor: 'pointer',
                                                    background: attendance[s.id] === 'present' ? '#10b981' : 'transparent',
                                                    color: attendance[s.id] === 'present' ? 'white' : '#94a3b8',
                                                    transition: 'all 0.2s'
                                                }}
                                            >
                                                <Check size={16} />
                                            </button>
                                            <button
                                                onClick={() => setAttendance({ ...attendance, [s.id]: 'absent' })}
                                                style={{
                                                    padding: '6px 16px', borderRadius: '10px', border: 'none', cursor: 'pointer',
                                                    background: attendance[s.id] === 'absent' ? '#ef4444' : 'transparent',
                                                    color: attendance[s.id] === 'absent' ? 'white' : '#94a3b8',
                                                    transition: 'all 0.2s'
                                                }}
                                            >
                                                <X size={16} />
                                            </button>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>

                            <div style={{ padding: '20px' }}>
                                <motion.button
                                    whileHover={{ scale: 1.01 }}
                                    whileTap={{ scale: 0.99 }}
                                    onClick={handleSave}
                                    disabled={saving}
                                    className="btn-primary"
                                    style={{ width: '100%', padding: '16px', borderRadius: '20px', fontSize: '1rem', fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}
                                >
                                    {saving ? 'Salvando...' : <><Send size={20} /> ENVIAR FREQUÊNCIA</>}
                                </motion.button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default Attendance;
